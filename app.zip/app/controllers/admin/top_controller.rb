class Admin::TopController < ApplicationController
  def index
  end
end
