class Admin::Base < ApplicationController
end
