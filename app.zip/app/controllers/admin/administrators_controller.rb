class Admin::AdministratorsController < Admin::Base
  def index
    
  end
end
