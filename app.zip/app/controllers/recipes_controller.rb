class RecipesController < ApplicationController
end
