class OrderSidemenu < ApplicationRecord
  belongs_to :order
  belongs_to :sidemenu
end
